# Design System Strategy: Precision & Fluidity

## 1. Overview & Creative North Star
**The Creative North Star: "The Orchestrated Core"**

For DP Sistemas y Automatizaciones, we are moving beyond the "blue corporate box." The Orchestrated Core represents a digital environment that feels as precise as a motherboard yet as fluid as automated data. We achieve this by breaking the traditional rigid grid through **intentional asymmetry** and **tonal layering**. 

While many tech brands feel sterile, this design system leans into a high-end editorial aesthetic. We utilize a dramatic contrast between the technical precision of the `Manrope` display face and the utilitarian clarity of `Inter`. Layouts should feel "curated" rather than "templated," using overlapping elements and shifting background depths to guide the user’s eye toward the "Efficiency Accents" (Bright Greens).

## 2. Color Architecture & The Surface Protocol

The palette is engineered to communicate "Technology" through depth, not just hue.

### The "No-Line" Rule
To maintain a premium, modern feel, **1px solid borders are prohibited for sectioning.** Boundaries must be defined through background color shifts. For instance, a `surface-container-low` section should sit directly on a `surface` background. The transition of tone is the divider.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, physical layers. 
- **Base:** `surface` (#f9f9fc)
- **Primary Content Areas:** `surface-container-low` (#f3f3f6)
- **Interactive Cards:** `surface-container-lowest` (#ffffff) to create a subtle "lift" against the background.
- **Utility Layers:** Use `surface-container-high` (#e8e8ea) for subtle nesting of inner data sets.

### The "Glass & Gradient" Rule
Standard flat colors feel static. To inject "Innovation," use **Glassmorphism** for floating navigation or overlays:
- **Style:** 60% opacity of `surface-container-lowest` with a 20px `backdrop-blur`.
- **Signature Textures:** Use a subtle linear gradient from `primary` (#003461) to `primary-container` (#004b87) for Hero backgrounds or primary CTAs to provide a sense of "visual soul."

## 3. Typography: The Editorial Tech Lens

Our typography scale balances the authority of a corporate leader with the agility of a startup.

*   **Display & Headlines (Manrope):** These are our "Voice." `display-lg` (3.5rem) should be used with tight letter-spacing (-0.02em) to feel authoritative and architectural. 
*   **Body & Labels (Inter):** These are our "Engine." `body-md` (0.875rem) is the workhorse for all technical descriptions and data, providing maximum legibility.
*   **Hierarchy Intent:** Use `headline-sm` in `primary` (#003461) to anchor sections, while using `label-md` in `on-surface-variant` (#424750) for metadata to ensure the UI feels layered and professional.

## 4. Elevation & Depth: Tonal Layering

We convey hierarchy through **Tonal Layering** rather than structural lines.

*   **The Layering Principle:** Depth is achieved by stacking. A `surface-container-lowest` card placed on a `surface-container-low` section creates a soft, natural lift without the "heaviness" of a shadow.
*   **Ambient Shadows:** For "Floating" elements (e.g., Modals), shadows must be extra-diffused. Use a blur of 32px with an 8% opacity of the `on-surface` color. It should feel like a natural light source, not a digital effect.
*   **The Ghost Border Fallback:** If a border is required for extreme accessibility, use the `outline-variant` (#c2c6d1) at **15% opacity**. Never use 100% opaque borders.
*   **Automation Accents:** The `tertiary` (#003c0b) and its variants represent "efficiency." Use `tertiary-fixed` (#98f994) for success states and micro-interactions to signify that the automation is active and healthy.

## 5. Components & Primitive Logic

### Buttons: The Tactile Triggers
*   **Primary:** Gradient of `primary` to `primary-container`. `xl` (0.75rem) corner radius. Use `on-primary` for text.
*   **Secondary:** `surface-container-highest` background with `on-surface` text. No border.
*   **Tertiary (Automation):** Use `secondary-container` (#7af1fc) for high-efficiency prompts, signaling a shift from standard navigation to "System Control."

### Cards & Data Lists
*   **The Divider Ban:** Do not use line dividers between list items. Use the **Spacing Scale** (specifically `12` or `16` units) to create breathing room, or alternate background tones slightly (`surface-container-low` vs `surface-container-lowest`).
*   **Cards:** Use `lg` (0.5rem) or `xl` (0.75rem) corner radius. Content should be padded by at least `6` (1.5rem) units to ensure an editorial, "un-cluttered" feel.

### Technical Icons
*   Icons should be "Line" style with a `1.5px` stroke weight, using the `secondary` (#006970) color to represent the "Cyan/Tech" aspect of the brand.

### Specialized Components
*   **Process Trackers:** Use a "Threaded" layout where nodes are `tertiary` (Green) and the connecting line is a subtle `outline-variant` gradient.
*   **Status Micro-Chips:** Small, high-contrast chips using `tertiary-container` for "Active" and `error-container` for "Halt."

## 6. Do’s and Don’ts

### Do:
*   **DO** use whitespace as a functional element. A "Professional" aesthetic requires breathing room.
*   **DO** lean into asymmetry. For example, left-aligning a headline while right-aligning the supporting body text creates a sophisticated editorial rhythm.
*   **DO** use the `tertiary` (Bright Green) sparingly. It is a "laser pointer," not a "paint brush." Use it only for automation-related highlights.

### Don't:
*   **DON'T** use black (#000000). Use `on-surface` (#1a1c1e) for all text to maintain a softer, premium contrast.
*   **DON'T** use traditional 1px dividers. If a section feels messy, increase the `Spacing Scale` instead of adding a line.
*   **DON'T** use "Standard" blue. Always ensure the `primary` (#003461) feels deep and "Navy-adjacent" to keep the brand feeling reliable and corporate-grade.